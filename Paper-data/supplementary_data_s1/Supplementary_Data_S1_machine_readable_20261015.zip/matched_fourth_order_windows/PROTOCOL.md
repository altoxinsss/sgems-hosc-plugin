# Matching and selection protocol

The analysis uses the archived uniform, primary-setting, 5 x 5 x 3 moving-window outputs for Sect. 4.5 from subvolumes z15_26, z45_56, and z75_86. Every complete window contains 75 porosity values. The complete-window centre ranges are x=3..73, y=3..98, and z=16..25, 46..55, or 76..85. The retained search support is the archived `analysis_valid` support, comprising facies-valid centres with valid numerical attributes.

## Pair criteria

Pairs are formed within the same subvolume. Let M denote mean, V population variance, h the number of values at least 0.25, and lambda3 skewness.

| Condition | Primary tolerances | Strict tolerances |
|---|---:|---:|
| Absolute mean difference | <=0.0025 | <=0.001 |
| Larger/smaller variance | <=1.05 | <=1.02 |
| Absolute high-porosity count difference | <=1 | =0 |
| Absolute skewness difference | <=0.10 | <=0.05 |

For both tolerance sets, windows share no coarse-grid cells: `abs(dx)>=5 or abs(dy)>=5 or abs(dz)>=3`. The criteria control four local summaries; excess kurtosis is reported separately.

The implementation uses a Chebyshev-distance query on `(M/0.0025, log(V)/log(1.05), h, lambda3/0.10)` to produce primary candidates, followed by explicit tests of the criteria and non-overlap. The tree query radius is `1+1e-10`; final mean tests allow `1e-15` and variance-ratio/skewness tests allow `1e-14` for floating-point boundaries. Counts are rounded from `75*high_fraction` to integers. These numerical allowances reproduce the original saved search.

## Score and ordering

The score is `D = abs(kappa4_A-kappa4_B) / ((V_A+V_B)/2)^2`. All primary candidates are ordered by decreasing D, then increasing original row index i, then j. The primary example is the first pair. The strict example is the first pair in that same ordering that satisfies the strict tolerances. The strict example's `rank` remains its rank in the primary candidate ordering.

For the z45_56 small-difference control, primary candidates are ordered by increasing D, then i, then j. The first pair whose two windows also have no shared coarse-grid cells with either window of the primary example is selected. Its recorded `rank` is again in the decreasing-D primary list.

## Window computations

All moments use denominator N=75. For porosity values phi_l:

```text
M = sum(phi_l)/N
mu_r = sum((phi_l-M)^r)/N
V = mu_2
kappa4 = mu_4 - 3*V^2
lambda3 = mu_3/V^(3/2)
lambda4 = kappa4/V^2
H = count(phi_l>=0.25)/N
standardized_phi_l = (phi_l-M)/sqrt(V)
single_cell_mu4_share_l = (phi_l-M)^4 / sum((phi_j-M)^4)
```

The empirical cumulative distribution assigns weight 1/75 to each observation. Identical observed values retain their separate contributions. For each selected window, all 600 original fine cells are retained; each coarse porosity value is the mean of its eight source values.

The decomposition stored in the metric export is:

```text
kappa4_A-kappa4_B = shape_term + scale_term
shape_term = (V_A^2+V_B^2)/2 * (lambda4_A-lambda4_B)
scale_term = (lambda4_A+lambda4_B)/2 * (V_A^2-V_B^2)
```

The displayed examples were selected to make fourth-order distributional contrasts visible within the specified matching conditions. The full screening summary and candidate reconstruction provide the corresponding search context.
