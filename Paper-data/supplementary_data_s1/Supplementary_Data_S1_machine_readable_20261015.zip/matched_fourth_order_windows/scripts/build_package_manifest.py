"""Create package/source hash manifests during release preparation."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", type=Path, required=True)
    parser.add_argument("--source-dir", type=Path, required=True,
                        help="Directory containing the original selected-window analysis exports.")
    args = parser.parse_args()
    package, source = args.package_dir.resolve(), args.source_dir.resolve()
    records = []
    for path in sorted(package.iterdir()):
        if path.suffix in (".csv", ".json") and (source / path.name).is_file():
            original = source / path.name
            if sha(original) != sha(path):
                raise ValueError(f"Copied input differs from original: {path.name}")
            records.append({"packaged_path": path.name, "source_filename": original.name,
                            "bytes": path.stat().st_size, "sha256": sha(path)})
    for target, original in (("source_provenance_original.json", "source_provenance.json"),
                             ("original_protocol.md", "protocol.md")):
        path = package / "provenance" / target
        if sha(path) != sha(source / original):
            raise ValueError(f"Provenance copy differs: {target}")
        records.append({"packaged_path": path.relative_to(package).as_posix(),
                        "source_filename": original, "bytes": path.stat().st_size,
                        "sha256": sha(path)})
    provenance = {"analysis_source_directory_name": source.name,
                  "copied_inputs": records,
                  "portable_scripts": [p.relative_to(package).as_posix()
                                       for p in sorted((package / "scripts").glob("*.py"))],
                  "statistical_protocol": "PROTOCOL.md"}
    (package / "provenance" / "packaged_sources.json").write_text(
        json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = []
    for path in sorted(package.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS" and "__pycache__" not in path.parts:
            lines.append(f"{sha(path)}  {path.relative_to(package).as_posix()}")
    (package / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"copied_source_files": len(records), "manifest_files": len(lines)}))


if __name__ == "__main__":
    main()
