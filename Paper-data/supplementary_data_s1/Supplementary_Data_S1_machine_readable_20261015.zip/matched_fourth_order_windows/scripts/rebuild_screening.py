"""Re-enumerate matched pairs from the three packaged verified window tables."""
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

DATASETS = ("z15_26", "z45_56", "z75_86")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    columns = {k: np.array([float(r[k]) for r in rows]) for k in rows[0] if k != "channel"}
    columns["channel"] = np.array([r["channel"] == "True" for r in rows])
    return columns


def nonoverlap(a, b):
    return np.any(np.abs(a - b) >= [5, 5, 3], axis=-1)


def quantiles(values):
    return {str(p): float(np.quantile(values, p)) for p in [0, .25, .5, .75, .9, .95, .99, 1]}


def pair_record(df, pair, score):
    i, j = map(int, pair)
    record = {"i": i, "j": j, "D": float(score)}
    for name in ("x", "y", "z", "mean", "variance", "high_fraction", "lambda3", "lambda4", "kappa4", "channel"):
        for side, index in (("A", i), ("B", j)):
            value = df[name][index].item()
            record[f"{name}_{side}"] = int(value) if name in "xyz" else value
    record["delta_mean"] = abs(record["mean_A"] - record["mean_B"])
    record["variance_ratio"] = max(record["variance_A"], record["variance_B"]) / min(record["variance_A"], record["variance_B"])
    record["delta_high_count"] = int(round(abs(record["high_fraction_A"] - record["high_fraction_B"]) * 75))
    record["delta_skew"] = abs(record["lambda3_A"] - record["lambda3_B"])
    return record


def write_csv(path, records):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def run(data_dir, output_dir, save_candidates):
    started = time.perf_counter()
    expected_summaries = {r["dataset"]: r for r in json.loads((data_dir / "screening_summary.json").read_text())}
    with (data_dir / "selected_pairs.csv").open(encoding="utf-8-sig", newline="") as f:
        expected_pairs = {(r["dataset"], r["role"]): r for r in csv.DictReader(f)}
    summaries, selected = [], []
    for dataset in DATASETS:
        df = load(data_dir / f"{dataset}_verified_window_statistics.csv")
        require(np.all(df["variance"] > 0), "Positive variances")
        require(np.all(df["center_channel_count"] != 4), "Facies-valid centers")
        features = np.column_stack((df["mean"] / .0025, np.log(df["variance"]) / np.log(1.05),
                                    df["high_fraction"] * 75, df["lambda3"] / .1))
        pair = cKDTree(features).query_pairs(1 + 1e-10, p=np.inf, output_type="ndarray")
        xyz = np.column_stack([df[a] for a in "xyz"])
        a, b = pair[:, 0], pair[:, 1]
        ratio = np.maximum(df["variance"][a], df["variance"][b]) / np.minimum(df["variance"][a], df["variance"][b])
        keep = nonoverlap(xyz[a], xyz[b])
        keep &= np.abs(df["mean"][a] - df["mean"][b]) <= .0025 + 1e-15
        keep &= ratio <= 1.05 + 1e-14
        keep &= np.abs(np.rint(df["high_fraction"][a] * 75) - np.rint(df["high_fraction"][b] * 75)) <= 1
        keep &= np.abs(df["lambda3"][a] - df["lambda3"][b]) <= .1 + 1e-14
        pair = pair[keep]
        a, b = pair[:, 0], pair[:, 1]
        score = np.abs(df["kappa4"][a] - df["kappa4"][b]) / ((df["variance"][a] + df["variance"][b]) / 2) ** 2
        order = np.lexsort((b, a, -score))
        pair, score = pair[order], score[order]
        a, b = pair[:, 0], pair[:, 1]
        strict = np.abs(df["mean"][a] - df["mean"][b]) <= .001 + 1e-15
        strict &= (np.maximum(df["variance"][a], df["variance"][b]) / np.minimum(df["variance"][a], df["variance"][b]) <= 1.02 + 1e-14)
        strict &= np.rint(df["high_fraction"][a] * 75) == np.rint(df["high_fraction"][b] * 75)
        strict &= np.abs(df["lambda3"][a] - df["lambda3"][b]) <= .05 + 1e-14
        summary = {"dataset": dataset, "all_complete_windows": 68160,
                   "analysis_valid_windows": len(xyz), "eligible_pairs": len(pair),
                   "matched_unique_windows": int(np.unique(pair).size),
                   "D_quantiles": quantiles(score), "strict_pairs": int(strict.sum()),
                   "strict_D_quantiles": quantiles(score[strict]),
                   "pairs_D_ge1": int((score >= 1).sum()),
                   "strict_pairs_D_ge1": int((score[strict] >= 1).sum())}
        for k, expected in expected_summaries[dataset].items():
            if isinstance(expected, dict):
                for q, number in expected.items():
                    require(np.isclose(summary[k][q], number, rtol=1e-9, atol=1e-12), f"{dataset}: {k}/{q}")
            else:
                require(summary[k] == expected, f"{dataset}: {k}: {summary[k]} != {expected}")
        summaries.append(summary)
        roles = [("primary", 0), ("strict", int(np.flatnonzero(strict)[0]))]
        if dataset == "z45_56":
            used = xyz[pair[0]]
            for index in np.lexsort((pair[:, 1], pair[:, 0], score)):
                if all(nonoverlap(xyz[j], used).all() for j in pair[index]):
                    roles.append(("small_difference_control", int(index)))
                    break
        for role, index in roles:
            record = pair_record(df, pair[index], score[index])
            record.update(dataset=dataset, role=role, rank=index + 1, strict=bool(strict[index]))
            expected = expected_pairs[(dataset, role)]
            for k in ("i", "j", "rank", "x_A", "x_B", "y_A", "y_B", "z_A", "z_B"):
                require(record[k] == int(expected[k]), f"{dataset}/{role}: {k}")
            require(np.isclose(record["D"], float(expected["D"]), rtol=1e-10, atol=1e-12), "Selected D")
            require(record["strict"] == (expected["strict"] == "True"), "Selected strict flag")
            selected.append(record)
        write_csv(output_dir / f"{dataset}_top100_pairs.csv",
                  [pair_record(df, p, d) for p, d in zip(pair[:100], score[:100])])
        write_csv(output_dir / f"{dataset}_strict_top100_pairs.csv",
                  [pair_record(df, p, d) for p, d in zip(pair[strict][:100], score[strict][:100])])
        if save_candidates:
            np.savez_compressed(output_dir / f"{dataset}_all_eligible_pairs.npz",
                                pairs=pair.astype(np.int32), D=score, strict=strict)
        print(f"{dataset}: {len(xyz)} windows; {len(pair)} primary pairs; {strict.sum()} strict pairs", flush=True)
    write_csv(output_dir / "selected_pairs.csv", selected)
    (output_dir / "screening_summary.json").write_text(json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
    report = {"status": "PASS", "datasets": 3, "windows": sum(s["analysis_valid_windows"] for s in summaries),
              "primary_pairs": sum(s["eligible_pairs"] for s in summaries),
              "strict_pairs": sum(s["strict_pairs"] for s in summaries),
              "selected_pairs_verified": len(selected), "elapsed_seconds": time.perf_counter() - started,
              "numpy_version": np.__version__}
    (output_dir / "screening_verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-dir", type=Path, required=True,
                        help="Directory outside the package for regenerated tables and reports.")
    parser.add_argument("--save-candidates", action="store_true",
                        help="Also write the complete candidate arrays as compressed NPZ files.")
    args = parser.parse_args()
    data_dir, output_dir = args.data_dir.resolve(), args.output_dir.resolve()
    require(data_dir != output_dir and data_dir not in output_dir.parents,
            "Choose an output directory outside the data package.")
    output_dir.mkdir(parents=True, exist_ok=True)
    run(data_dir, output_dir, args.save_candidates)


if __name__ == "__main__":
    main()
