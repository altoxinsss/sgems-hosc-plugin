"""Recompute selected 75-cell windows and their 600 source cells (stdlib only)."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from math import comb
from pathlib import Path

D = Decimal
DATASETS = {"z15_26": 15, "z45_56": 45, "z75_86": 75}
ATTRIBUTES = ("mean", "variance", "high_fraction", "lambda3", "lambda4", "kappa4")


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(a, b, name, rtol=D("1e-11"), atol=D("1e-17")):
    a, b = D(str(a)), D(str(b))
    error = abs(a - b)
    require(error <= atol + rtol * max(abs(a), abs(b)), f"{name}: {a} != {b}")
    return error


def key(row):
    return row["dataset"], row["role"], row.get("side", row.get("window"))


def xyz(row, prefix=""):
    return tuple(int(row[prefix + axis]) for axis in "xyz")


def groups(rows):
    result = defaultdict(list)
    for row in rows:
        result[key(row)].append(row)
    return result


def support(center):
    x, y, z = center
    return {(i, j, k) for i in range(x - 2, x + 3)
            for j in range(y - 2, y + 3) for k in range(z - 1, z + 2)}


def calculate(values):
    n = D(len(values))
    mean = sum(values) / n
    centered = [v - mean for v in values]
    mu = {r: sum(v ** r for v in centered) / n for r in (2, 3, 4)}
    raw = {r: sum(v ** r for v in values) / n for r in range(1, 5)}
    cumulants = {1: raw[1]}
    for r in range(2, 5):
        cumulants[r] = raw[r] - sum(
            D(comb(r - 1, j - 1)) * cumulants[j] * raw[r - j]
            for j in range(1, r)
        )
    k4 = mu[4] - 3 * mu[2] ** 2
    require(abs(cumulants[4] - k4) < D("1e-45"), "Raw/central fourth identity")
    high_count = sum(v >= D("0.25") for v in values)
    fourth = [v ** 4 for v in centered]
    return {
        "mean": mean, "variance": mu[2], "high_count": high_count,
        "high_fraction": D(high_count) / n,
        "lambda3": mu[3] / (mu[2] * mu[2].sqrt()),
        "lambda4": k4 / mu[2] ** 2, "kappa4": k4, "mu4": mu[4],
        "minimum": min(values), "maximum": max(values),
        "largest_one_mu4_fraction": max(fourth) / sum(fourth),
        "below_027_count": sum(v < D("0.27") for v in values),
        "raw_central_kappa4_difference": abs(cumulants[4] - k4),
    }


def verify_manifest(data_dir):
    manifest = data_dir / "SHA256SUMS"
    require(manifest.is_file(), f"Missing manifest: {manifest}")
    count = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        path = data_dir / relative
        require(path.is_file(), f"Missing packaged file: {relative}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        require(actual == expected, f"SHA-256 mismatch: {relative}")
        count += 1
    return count


def verify(data_dir):
    manifest_files = verify_manifest(data_dir)
    pairs = read_csv(data_dir / "selected_pairs.csv")
    raw = groups(read_csv(data_dir / "selected_window_raw_values.csv"))
    coarse = groups(read_csv(data_dir / "geological_context_coarse_cells.csv"))
    fine = groups(read_csv(data_dir / "geological_context_fine_cells.csv"))
    independent = groups(read_csv(data_dir / "independently_extracted_samples.csv"))
    metrics = {key(r): r for r in read_csv(data_dir / "selected_window_metrics.csv")}
    geological = {key(r): r for r in read_csv(data_dir / "geological_context_windows.csv")}
    expected_keys = {(r["dataset"], r["role"], side) for r in pairs for side in "AB"}
    for label, mapping in (("raw", raw), ("coarse", coarse), ("fine", fine),
                           ("independent", independent), ("metrics", metrics),
                           ("geological", geological)):
        require(set(mapping) == expected_keys, f"Window identities: {label}")
    summary = []
    results = {}
    locations = {}
    max_fine_coarse_error = D(0)
    max_stored_metric_error = {a: D(0) for a in ATTRIBUTES}
    for pair in pairs:
        for side in "AB":
            identity = pair["dataset"], pair["role"], side
            center = tuple(int(pair[f"{axis}_{side}"]) for axis in "xyz")
            points = support(center)
            locations[identity] = points
            require(len(raw[identity]) == 75, f"75 coarse rows: {identity}")
            require(len(coarse[identity]) == 75, f"75 geological coarse rows: {identity}")
            require(len(fine[identity]) == 600, f"600 source rows: {identity}")
            require(len(independent[identity]) == 75, f"75 independent rows: {identity}")
            raw_by_xyz = {xyz(r): r for r in raw[identity]}
            coarse_by_xyz = {xyz(r, "coarse_"): r for r in coarse[identity]}
            independent_by_xyz = {xyz(r): r for r in independent[identity]}
            require(set(raw_by_xyz) == set(coarse_by_xyz) == set(independent_by_xyz) == points,
                    f"Complete 5 x 5 x 3 support: {identity}")
            by_coarse = defaultdict(list)
            all_fine_xyz = set()
            for row in fine[identity]:
                coord = tuple(int(row[f"source_fine_{axis}_1based"]) for axis in "xyz")
                require(coord not in all_fine_xyz, f"Duplicate fine cell: {identity}, {coord}")
                all_fine_xyz.add(coord)
                by_coarse[xyz(row, "coarse_")].append(row)
            require(set(by_coarse) == points, f"Fine/coarse mapping: {identity}")
            values = [D(raw_by_xyz[p]["porosity"]) for p in sorted(points)]
            stats = calculate(values)
            results[identity] = stats
            hist = Counter()
            n_counts = Counter()
            min_points = []
            max_points = []
            for p in sorted(points):
                x, y, z = p
                block = by_coarse[p]
                require(len(block) == 8, f"Eight source cells: {identity}, {p}")
                fine_start = (2 * (x - 1) + 1, 2 * (100 - y) + 1, 2 * (100 - z) + 1)
                expected = {(fine_start[0] + dx, fine_start[1] + dy, fine_start[2] + dz)
                            for dx in (0, 1) for dy in (0, 1) for dz in (0, 1)}
                actual = {tuple(int(r[f"source_fine_{a}_1based"]) for a in "xyz") for r in block}
                require(actual == expected, f"Preprocessing coordinate map: {identity}, {p}")
                phi = D(raw_by_xyz[p]["porosity"])
                fp = sum(D(r["porosity"]) for r in block) / 8
                error = close(fp, phi, f"Eight-cell porosity mean {identity}, {p}",
                              rtol=D(0), atol=D("1e-14"))
                max_fine_coarse_error = max(max_fine_coarse_error, error)
                close(phi, coarse_by_xyz[p]["coarse_phi"], "Stored coarse porosity")
                close(phi, independent_by_xyz[p]["porosity"], "Independent coordinate extraction")
                counts = Counter(int(r["facies"]) for r in block)
                require(set(counts).issubset({0, 1, 2, 3}), "Facies code set")
                nc = counts[2]
                require(nc == int(raw_by_xyz[p]["channel_count"])
                        == int(coarse_by_xyz[p]["nC"])
                        == int(independent_by_xyz[p]["channel_count"]), "Channel counts")
                hist.update(counts)
                n_counts[nc] += 1
                for code, column in enumerate(("floodplain_0", "point_bar_1", "channel_2", "boundary_3")):
                    require(counts[code] == int(coarse_by_xyz[p][column]), "Coarse facies histogram")
                standardized = (phi - stats["mean"]) / stats["variance"].sqrt()
                close(standardized, raw_by_xyz[p]["standardized_phi"], "Standardized sample",
                      atol=D("1e-12"))
                if phi == stats["minimum"]:
                    min_points.append(p)
                if phi == stats["maximum"]:
                    max_points.append(p)
            require(int(raw_by_xyz[center]["channel_count"]) != 4, "Facies-valid center")
            for attribute in ATTRIBUTES:
                error = close(stats[attribute], pair[f"{attribute}_{side}"],
                              f"Selected-pair metric {identity}: {attribute}")
                max_stored_metric_error[attribute] = max(max_stored_metric_error[attribute], error)
                if attribute in metrics[identity]:
                    close(stats[attribute], metrics[identity][attribute], f"Metric export {attribute}")
            close(stats["largest_one_mu4_fraction"], metrics[identity]["largest_one_mu4_fraction"],
                  "Largest fourth-moment contribution")
            for code, column in enumerate(("floodplain_0", "point_bar_1", "channel_2", "boundary_3")):
                require(hist[code] == int(geological[identity][column]), "Window facies histogram")
            for nc in range(9):
                require(n_counts[nc] == int(geological[identity][f"nC_{nc}"]), "nC histogram")
            summary.append({"dataset": identity[0], "role": identity[1], "window": side,
                            "center": center, "coarse_cells": 75, "fine_cells": 600,
                            **stats, "facies_counts_0_1_2_3": [hist[i] for i in range(4)],
                            "minimum_locations": min_points, "maximum_locations": max_points})
    pair_results = []
    for pair in pairs:
        prefix = pair["dataset"], pair["role"]
        a, b = results[prefix + ("A",)], results[prefix + ("B",)]
        require(locations[prefix + ("A",)].isdisjoint(locations[prefix + ("B",)]),
                f"Non-overlap: {prefix}")
        dm = abs(a["mean"] - b["mean"])
        vr = max(a["variance"], b["variance"]) / min(a["variance"], b["variance"])
        dh = abs(a["high_count"] - b["high_count"])
        ds = abs(a["lambda3"] - b["lambda3"])
        require(dm <= D("0.0025") and vr <= D("1.05") and dh <= 1 and ds <= D("0.10"),
                f"Primary matching: {prefix}")
        strict = dm <= D("0.001") and vr <= D("1.02") and dh == 0 and ds <= D("0.05")
        require(strict == (pair["strict"] == "True"), f"Strict matching flag: {prefix}")
        score = abs(a["kappa4"] - b["kappa4"]) / ((a["variance"] + b["variance"]) / 2) ** 2
        close(score, pair["D"], "Scaled fourth-cumulant difference", atol=D("1e-11"))
        pair_results.append({"dataset": prefix[0], "role": prefix[1], "nonoverlap": True,
                             "primary_matching": True, "strict_matching": strict,
                             "delta_mean": dm, "variance_ratio": vr,
                             "delta_high_count": dh, "delta_skew": ds, "D": score})
    for side in "AB":
        for other in "AB":
            require(locations[("z45_56", "small_difference_control", side)].isdisjoint(
                locations[("z45_56", "primary", other)]), "Control/primary non-overlap")
    return {"status": "PASS", "manifest_files_checked": manifest_files,
            "pairs_checked": len(pairs), "windows_checked": len(summary),
            "coarse_rows_checked": sum(map(len, raw.values())),
            "fine_rows_checked": sum(map(len, fine.values())),
            "decimal_precision": 50, "max_fine_coarse_error": max_fine_coarse_error,
            "max_stored_metric_errors": max_stored_metric_error,
            "pairs": pair_results, "windows": summary}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1],
                        help="Directory containing the packaged CSV files; defaults to the package.")
    parser.add_argument("--output-dir", type=Path, required=True,
                        help="New output directory outside the package for the JSON verification report.")
    args = parser.parse_args()
    data_dir, output_dir = args.data_dir.resolve(), args.output_dir.resolve()
    require(data_dir != output_dir and data_dir not in output_dir.parents,
            "Choose an output directory outside the data package.")
    output_dir.mkdir(parents=True, exist_ok=True)
    with localcontext() as context:
        context.prec = 50
        report = verify(data_dir)
    destination = output_dir / "selected_windows_verification.json"
    destination.write_text(json.dumps(report, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in (
        "status", "manifest_files_checked", "pairs_checked", "windows_checked",
        "coarse_rows_checked", "fine_rows_checked", "max_fine_coarse_error")}, default=str))
    print(f"Report: {destination}")


if __name__ == "__main__":
    main()
