# Figure S16 reproduction

`make_figure_s16.py` generates the editable SVG using Python 3.9 or later and standard-library modules only. It requires no NumPy, Matplotlib, GIS application, or local machine configuration.

Recommended package layout:

```text
matched_fourth_order_windows/
    selected_window_raw_values.csv
    selected_pairs.csv
    scripts/
        make_figure_s16.py
        export_figure_s16_optional.cjs
        README_Figure_S16.md
```

From any working directory:

```sh
python path/to/matched_fourth_order_windows/scripts/make_figure_s16.py --output-dir output
```

Without `--output-dir`, files are written to the current working directory. Inputs are located relative to the script directory, not the working directory. An alternate input location is supported:

```sh
python make_figure_s16.py --data-dir path/to/csv_files --output-dir output
```

The script writes `Figure_S16_strict_matched_windows.svg` and `Figure_S16_reproduction_checks.json`. It checks the complete 5 × 5 × 3 support and 75 observations of each window, independently recomputes population mean/variance and standardization, and compares the moments with `selected_pairs.csv`. Stored full-precision standardized values are used only after passing this check, preserving the published curve coordinates. All 75 observations contribute to each empirical cumulative distribution, including tied values. No smoothing is performed.

The plot contains raw and standardized ECDFs for `z15_26_strict` in the upper row and `z75_86_strict` in the lower row. Insets enlarge the upper tails. A is blue/solid; B is orange/dashed. Labels and curves remain vector objects.

SVG line endings are explicitly fixed to CRLF so the expected SHA-256 is the same across operating systems:

```text
2b7906ed230ca06a86000f82348c752ac2c158b5b3761be39f3305138b77e808
```

SVG text requests Arial, with a sans-serif fallback. Arial must be available to the rasterizer to reproduce the supplied TIFF typography exactly; the SVG data and geometry do not depend on font installation.

Optional raster export uses Node.js with the `sharp` package:

```sh
npm install sharp
node export_figure_s16_optional.cjs output/Figure_S16_strict_matched_windows.svg output
```

This produces an RGB LZW TIFF of 8221 × 7323 pixels at 1200 dpi, corresponding to approximately 174 × 155 mm, plus a PNG preview. The SVG alone is sufficient to reproduce the plotted data and editable figure. No absolute machine paths are built into either script.
