#!/usr/bin/env python3
"""Reproduce Figure S16 using Python 3.9+ standard-library modules only.

Default input layout:
  selected_window_raw_values.csv
  selected_pairs.csv
  scripts/make_figure_s16.py

Input paths are relative to this script, independent of the working directory.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import html
import json
import math
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument('--data-dir', type=Path, default=Path(__file__).resolve().parent.parent,
                    help='Directory containing the two CSV files; default: parent of script directory')
parser.add_argument('--output-dir', type=Path, default=Path.cwd(),
                    help='Output directory; default: current working directory')
args = parser.parse_args()
OUT, DATA = args.output_dir.resolve(), args.data_dir.resolve()
SOURCE, PAIRS = DATA/'selected_window_raw_values.csv', DATA/'selected_pairs.csv'
W, H = 174 / 25.4 * 72, 155 / 25.4 * 72
COLORS = {'A': '#0072B2', 'B': '#D55E00'}
CASES = [
    ('z15_26_strict', 'z15–26', {'A': (68, 26, 17), 'B': (54, 51, 18)}),
    ('z75_86_strict', 'z75–86', {'A': (58, 63, 77), 'B': (32, 70, 78)}),
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def mean(values):
    return math.fsum(values)/len(values)

for required in (SOURCE, PAIRS):
    if not required.is_file():
        parser.error('Missing input: '+str(required))
with SOURCE.open(encoding='utf-8-sig', newline='') as stream:
    rows = list(csv.DictReader(stream))
with PAIRS.open(encoding='utf-8-sig', newline='') as stream:
    pairs = list(csv.DictReader(stream))
windows, checks = {}, []
for case, title, centers in CASES:
    pair = next(p for p in pairs if p['dataset'] == case.replace('_strict', '') and p['role'] == 'strict')
    for letter, center in centers.items():
        selected = [r for r in rows if r['case'] == case and r['window'] == letter]
        assert len(selected) == 75
        assert {tuple(int(r[k]) for k in ['center_x','center_y','center_z']) for r in selected} == {center}
        coords = {tuple(int(r[k]) for k in ['x','y','z']) for r in selected}
        expected = {(x,y,z) for x in range(center[0]-2,center[0]+3)
                    for y in range(center[1]-2,center[1]+3)
                    for z in range(center[2]-1,center[2]+2)}
        assert len(coords) == 75 and coords == expected
        values = [float(r['porosity']) for r in selected]
        assert all(math.isfinite(v) for v in values)
        m = mean(values)
        variance = mean([(v-m)**2 for v in values])
        assert variance > 0
        recomputed = [(v-m)/math.sqrt(variance) for v in values]
        recorded = [float(r['standardized_phi']) for r in selected]
        standardization_error = max(abs(a-b) for a,b in zip(recorded,recomputed))
        assert standardization_error < 1e-12
        # Preserve the published full-precision coordinates after independently
        # checking their population-mean/population-SD definition from raw data.
        std = recorded
        kappa4 = mean([(v-m)**4 for v in values])-3*variance**2
        lambda4 = mean([v**4 for v in recomputed])-3
        for field,result in [('mean',m),('variance',variance),('kappa4',kappa4),('lambda4',lambda4)]:
            assert math.isclose(result,float(pair[f'{field}_{letter}']),rel_tol=1e-12,abs_tol=1e-20)
        windows[(case,letter)] = {'raw':values,'standardized':std,'center':center}
        checks.append({'case':case,'window':letter,'center':list(center),'n':75,
                       'unique_grid_nodes':len(coords),'complete_5x5x3_support':True,
                       'mean':m,'population_variance':variance,'kappa4':kappa4,
                       'excess_kurtosis':lambda4,'min_porosity':min(values),'max_porosity':max(values),
                       'minimum_standardized':min(std),'maximum_standardized':max(std),
                       'maximum_difference_from_recomputed_standardized_values':standardization_error})

parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="174mm" height="155mm" viewBox="0 0 {W:.8f} {H:.8f}">',
         '<metadata>Figure S16. ECDF steps preserve all 75 observed values per window; population standardization. No smoothing.</metadata>',
         '<style>text { font-family: Arial, sans-serif; fill: #000000; } path, line, rect { stroke-linejoin: round; }</style>',
         f'<rect width="{W:.8f}" height="{H:.8f}" fill="#ffffff"/>']

def text(x,y,value,size=8.1,anchor='start',weight='normal',**attrs):
    extra=''.join(f' {k.replace("_","-")}="{html.escape(str(v),quote=True)}"' for k,v in attrs.items())
    parts.append(f'<text x="{x:.6f}" y="{y:.6f}" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}"{extra}>{html.escape(str(value))}</text>')

def line(x1,y1,x2,y2,stroke='#000000',width=.65,dash=''):
    extra=f' stroke-dasharray="{dash}"' if dash else ''
    parts.append(f'<line x1="{x1:.6f}" y1="{y1:.6f}" x2="{x2:.6f}" y2="{y2:.6f}" stroke="{stroke}" stroke-width="{width}"{extra}/>')

def ecdf_path(case,letter,kind,x,y,w,h,xlim,ylim,clip_id,inset=False):
    vals=sorted(windows[(case,letter)][kind])
    points=[(min(xlim[0],float(vals[0])),0.0)]
    for i,v in enumerate(vals):
        points.extend([(float(v),i/75),(float(v),(i+1)/75)])
    points.append((max(xlim[1],float(vals[-1])),1.0))
    tx=lambda v:x+(v-xlim[0])/(xlim[1]-xlim[0])*w
    ty=lambda v:y+h-(v-ylim[0])/(ylim[1]-ylim[0])*h
    d=' '.join(('M' if i==0 else 'L')+f'{tx(a):.8f},{ty(b):.8f}' for i,(a,b) in enumerate(points))
    dashed='' if letter=='A' else ' stroke-dasharray="4 2"'
    parts.append(f'<path id="ecdf-{clip_id}-{letter}" data-case="{case}" data-window="{letter}" data-samples="75" data-representation="{kind}" d="{d}" fill="none" stroke="{COLORS[letter]}" stroke-width="{.9 if inset else 1.15}"{dashed} clip-path="url(#{clip_id})"/>')

def axes(x,y,w,h,xlim,ylim,xticks,yticks,clip_id,inset=False):
    parts.append(f'<defs><clipPath id="{clip_id}"><rect x="{x:.6f}" y="{y:.6f}" width="{w:.6f}" height="{h:.6f}"/></clipPath></defs>')
    parts.append(f'<rect x="{x:.6f}" y="{y:.6f}" width="{w:.6f}" height="{h:.6f}" fill="#ffffff"/>')
    tx=lambda v:x+(v-xlim[0])/(xlim[1]-xlim[0])*w
    ty=lambda v:y+h-(v-ylim[0])/(ylim[1]-ylim[0])*h
    size=6.1 if inset else 7.7
    ticklen=2 if inset else 3
    for val,label in xticks:
        a=tx(val);line(a,y,a,y+h,stroke='#dedede',width=.4 if inset else .45)
        line(a,y+h,a,y+h+ticklen,width=.5 if inset else .6)
        text(a,y+h+ticklen+size*.95,label,size=size,anchor='middle')
    for val,label in yticks:
        b=ty(val);line(x,b,x+w,b,stroke='#dedede',width=.4 if inset else .45)
        line(x-ticklen,b,x,b,width=.5 if inset else .6)
        text(x-ticklen-2,b+size*.34,label,size=size,anchor='end')
    parts.append(f'<rect x="{x:.6f}" y="{y:.6f}" width="{w:.6f}" height="{h:.6f}" fill="none" stroke="#000000" stroke-width="{.5 if inset else .65}"/>')

for row,(case,title,centers) in enumerate(CASES):
    top=40+row*213
    subtitle='; '.join(f'{letter}: ({c[0]}, {c[1]}, {c[2]})' for letter,c in centers.items())
    for col,kind in enumerate(['raw','standardized']):
        x,y,w,h=(46 if col==0 else 291),top,182,141
        letter='abcd'[row*2+col]
        text(x,top-23,f'({letter}) {title}: '+('raw porosity' if col==0 else 'standardized porosity'),size=9.2)
        text(x,top-10,subtitle,size=7.2)
        xlim=(.04,.195) if col==0 else (-2,7.5)
        xt=[(.04,'0.04'),(.08,'0.08'),(.12,'0.12'),(.16,'0.16')] if col==0 else [(-2,'−2'),(0,'0'),(2,'2'),(4,'4'),(6,'6')]
        yt=[(i*.2,f'{i*.2:.1f}') for i in range(6)]
        clip_id=f'panel-{letter}'
        axes(x,y,w,h,xlim,(0,1.025),xt,yt,clip_id)
        for window in ['A','B']:ecdf_path(case,window,kind,x,y,w,h,xlim,(0,1.025),clip_id)
        text(x+w/2,y+h+25,'Porosity' if col==0 else 'Standardized porosity',size=8.2,anchor='middle')
        text(x-32,y+h/2,'Empirical cumulative probability',size=8.2,anchor='middle',transform=f'rotate(-90 {x-32} {y+h/2})')
        for i,window in enumerate(['A','B']):
            ly=y+24+i*13
            line(x+100,ly,x+120,ly,stroke=COLORS[window],width=1.15,dash='' if window=='A' else '4 2')
            text(x+125,ly+2.6,f'{window} (N = 75)',size=7.4)
        ix,iy,iw,ih=x+93,y+59,82,58
        ilim=(.09,.195) if col==0 else (1.5,7.5)
        iticks=[(.10,'0.10'),(.14,'0.14'),(.18,'0.18')] if col==0 else [(2,'2'),(4,'4'),(6,'6')]
        axes(ix,iy,iw,ih,ilim,(.88,1.005),iticks,[(.90,'0.90'),(.95,'0.95'),(1.,'1.00')],f'inset-{letter}',inset=True)
        for window in ['A','B']:ecdf_path(case,window,kind,ix,iy,iw,ih,ilim,(.88,1.005),f'inset-{letter}',inset=True)
        text(ix+iw/2,iy-5,'Upper tail',size=6.8,anchor='middle')

text(W/2,H-4,'Uniform 5 × 5 × 3 windows; all 75 values per curve.',size=8,anchor='middle')
parts.append('</svg>')
OUT.mkdir(parents=True,exist_ok=True)
svg=OUT/'Figure_S16_strict_matched_windows.svg'
with svg.open('w', encoding='utf-8', newline='\r\n') as stream:
    stream.write('\n'.join(parts))
root=ET.parse(svg)
assert not root.findall('.//{http://www.w3.org/2000/svg}image')
paths=[p for p in root.findall('.//{http://www.w3.org/2000/svg}path') if p.get('id','').startswith('ecdf-')]
assert len(paths)==16 and all(p.get('data-samples')=='75' for p in paths)
manifest={'source_csv_sha256':sha(SOURCE),'selected_pairs_sha256':sha(PAIRS),'windows':checks,
          'canvas_mm':[174,155],'font':'Arial, sans-serif','vector_ecdf_paths':len(paths),
          'svg_editable_text_count':len(root.findall('.//{http://www.w3.org/2000/svg}text')),
          'svg_embedded_image_count':0,'curve_interpolation':'ECDF steps only; no smoothing',
          'standardization':'Stored full-precision standardized_phi verified against raw-data population mean and standard deviation',
          'insets':'Upper tail, cumulative probability 0.88 to 1.005','svg_sha256':sha(svg)}
(OUT/'Figure_S16_reproduction_checks.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('SVG: '+str(svg))
print('SHA-256: '+sha(svg))
