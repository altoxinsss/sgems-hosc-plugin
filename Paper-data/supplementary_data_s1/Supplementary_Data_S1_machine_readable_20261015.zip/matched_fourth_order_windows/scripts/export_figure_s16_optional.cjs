/* Optional: npm install sharp, then node this-file.cjs input.svg [output-dir]. */
const fs=require('node:fs'),path=require('node:path');
let sharp;
try { sharp=require('sharp'); }
catch(e) { console.error('Optional raster export requires the sharp package. SVG reproduction itself uses only Python standard-library modules.');process.exit(1); }
const input=process.argv[2];
if(!input){console.error('Usage: node export_figure_s16_optional.cjs input.svg [output-dir]');process.exit(1);}
const out=path.resolve(process.argv[3]||process.cwd());
const stem='Figure_S16_strict_matched_windows';
const width=Math.ceil(174/25.4*1200),height=Math.ceil(155/25.4*1200);
(async()=>{
  fs.mkdirSync(out,{recursive:true});
  const tiff=path.join(out,stem+'.tiff');
  await sharp(path.resolve(input),{density:1200,limitInputPixels:false})
    .resize(width,height,{fit:'fill'}).flatten({background:'#ffffff'}).removeAlpha()
    .withMetadata({density:1200}).tiff({compression:'lzw',predictor:'horizontal'}).toFile(tiff);
  await sharp(tiff,{limitInputPixels:false}).resize(1400).png().toFile(path.join(out,stem+'_preview.png'));
  console.log(`Exported ${width} x ${height} RGB LZW TIFF at 1200 dpi: ${tiff}`);
})().catch(e=>{console.error(e.message);process.exit(1);});
