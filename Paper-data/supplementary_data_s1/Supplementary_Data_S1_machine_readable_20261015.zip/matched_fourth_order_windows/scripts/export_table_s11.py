"""Reproduce the three machine-readable panels of Supplementary Table S11."""
import argparse
import csv
import json
from pathlib import Path


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def create_panels(data_dir):
    summaries = json.loads((data_dir / "screening_summary.json").read_text(encoding="utf-8"))
    pairs = [r for r in read_csv(data_dir / "selected_pairs.csv") if r["role"] == "strict"]
    geological = {(r["dataset"], r["side"]): r for r in
                  read_csv(data_dir / "geological_context_windows.csv") if r["role"] == "strict"}
    samples = read_csv(data_dir / "selected_window_raw_values.csv")
    panel_a = [{"subvolume": r["dataset"], "complete_windows": r["all_complete_windows"],
                "facies_valid_windows": r["analysis_valid_windows"],
                "main_tolerance_pairs": r["eligible_pairs"], "strict_tolerance_pairs": r["strict_pairs"]}
               for r in summaries]
    panel_b, panel_c = [], []
    for pair in pairs:
        dataset = pair["dataset"]
        row = {"subvolume": dataset}
        for side in "AB":
            for axis in "xyz":
                row[f"center_{side}_{axis}"] = int(pair[f"{axis}_{side}"])
        for dest, source in (("abs_delta_mean", "delta_mean"),
                             ("larger_to_smaller_variance_ratio", "variance_ratio"),
                             ("abs_delta_high_count", "delta_high_count"),
                             ("abs_delta_skewness", "delta_skew"),
                             ("scaled_fourth_cumulant_difference", "D")):
            row[dest] = int(pair[source]) if source == "delta_high_count" else float(pair[source])
        for attribute in ("mean", "variance", "high_fraction", "lambda3", "lambda4", "kappa4"):
            for side in "AB":
                row[f"{attribute}_{side}"] = float(pair[f"{attribute}_{side}"])
        panel_b.append(row)
        for side in "AB":
            geo = geological[(dataset, side)]
            rows = [r for r in samples if r["dataset"] == dataset and r["role"] == "strict"
                    and r["window"] == side]
            if len(rows) != 75:
                raise ValueError(f"Incomplete support: {dataset}/{side}")
            record = {"subvolume": dataset, "window": side}
            for axis in "xyz":
                record[f"center_{axis}"] = int(pair[f"{axis}_{side}"])
            record["source_fine_cell_count"] = 600
            for column in ("floodplain_0", "point_bar_1", "channel_2", "boundary_3"):
                record[column] = int(geo[column])
            for name, function in (("min", min), ("max", max)):
                value = function(float(r["porosity"]) for r in rows)
                record[f"{name}_porosity"] = value
                coordinates = [tuple(int(r[a]) for a in "xyz") for r in rows if float(r["porosity"]) == value]
                record[f"{name}_coarse_locations"] = "; ".join(
                    "(" + ",".join(map(str, point)) + ")" for point in coordinates)
            panel_c.append(record)
    return {"Table_S11_screening_support.csv": panel_a,
            "Table_S11_matched_attributes.csv": panel_b,
            "Table_S11_facies_extrema.csv": panel_c}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-dir", type=Path,
                        help="Directory for CSV panels. With --check, defaults to --data-dir.")
    parser.add_argument("--check", action="store_true", help="Compare CSV panels with their packaged source records.")
    args = parser.parse_args()
    output = args.output_dir or (args.data_dir if args.check else None)
    if output is None:
        parser.error("--output-dir is required when generating files")
    output.mkdir(parents=True, exist_ok=True)
    for filename, rows in create_panels(args.data_dir).items():
        if args.check:
            expected = [{k: str(v) for k, v in row.items()} for row in rows]
            if read_csv(output / filename) != expected:
                raise ValueError(f"Table panel mismatch: {filename}")
        else:
            with (output / filename).open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
        print(f"{'Checked' if args.check else 'Wrote'} {filename}: {len(rows)} rows")


if __name__ == "__main__":
    main()
