# Matched fourth order moving window examples

This package supplies the numerical evidence for manuscript Fig. 8 and Table 4 and Supplementary Table S11 and Fig. S16. It contains seven selected pairs, their 14 complete uniform 5 x 5 x 3 windows, and the verified window statistics used to enumerate candidates throughout three Stanford VI-E subvolumes.

The manuscript pair is `dataset=z45_56, role=strict`: A is centred at (52,17,47), and B at (42,7,48). Each window contains 75 coarse-grid porosity values. The corresponding 600 original fine-grid porosity values and facies labels are included. Original and standardized empirical cumulative distributions use the complete 75-value support.

## Reproduce the selected windows

Python 3.10 or later is sufficient for the selected-window verification; the script uses the standard library. From this directory, run:

```text
python scripts/verify_selected_windows.py --output-dir ../matched_window_checks
```

The default input directory is resolved from the script location, so the script also works when called from another working directory. An alternative input location can be supplied with `--data-dir`.

The script checks the SHA-256 manifest, reconstructs each 75-cell support, associates all eight source cells with each coarse cell, recomputes the coarse porosity means and facies histograms, and checks mean, population variance, high-porosity fraction, skewness, fourth cumulant, excess kurtosis, standardization, matching conditions, and non-overlap. Raw-moment recurrence and central-moment expressions are evaluated independently with 50-digit Decimal arithmetic. The generated JSON report contains the recomputed attributes, minimum-value locations, original-facies counts, and numerical errors.

## Rebuild the complete candidate search

Install NumPy and SciPy in the Python environment, then run:

```text
python -m pip install -r requirements.txt
python scripts/rebuild_screening.py --output-dir ../matched_window_screening --save-candidates
```

The three `*_verified_window_statistics.csv` files are the inputs. They contain 197,280 facies-valid windows in total. The script re-enumerates the complete same-subvolume primary-tolerance candidate set, applies the strict tolerances, sorts by the scaled fourth-cumulant difference, and reconstructs the selected primary, strict, and small-difference-control records. It checks candidate counts, score quantiles, selected coordinates, row indices, ranks, and strict flags against the archived results. Expected counts are:

| Subvolume | Complete windows | Facies-valid windows | Primary-tolerance pairs | Strict-tolerance pairs |
|---|---:|---:|---:|---:|
| z15_26 | 68,160 | 67,332 | 600,313 | 46,490 |
| z45_56 | 68,160 | 66,485 | 441,705 | 33,077 |
| z75_86 | 68,160 | 63,463 | 415,208 | 14,718 |

Outputs include the full screening summary, selected pairs, and the first 100 primary/strict candidates from each subvolume. `--save-candidates` also writes all candidate indices, scores, and strict flags as compressed NPZ files. The reconstruction uses archived numerical outputs and is a post-processing calculation.

The three Table S11 CSV panels can be checked with `python scripts/export_table_s11.py --check` or regenerated in a separate directory with `python scripts/export_table_s11.py --output-dir ../table_s11_rebuilt`. This script uses the Python standard library.

## Files and column meanings

| File | Contents |
|---|---|
| `selected_pairs.csv` | Seven pair records. `i,j` are zero-based row indices in the corresponding verified-statistics CSV; `rank` is one-based in the primary-tolerance candidate list sorted by decreasing `D`. |
| `Table_S11_screening_support.csv` | Table S11 Panel A: search support and candidate counts. |
| `Table_S11_matched_attributes.csv` | Table S11 Panel B: strict-pair coordinates, matching differences, and complete local statistics. |
| `Table_S11_facies_extrema.csv` | Table S11 Panel C: six strict windows, original-facies counts, and minimum/maximum locations; all tied extrema are retained. |
| `screening_summary.json` | Support counts, candidate counts, unique participating windows, and score quantiles. |
| `selected_window_raw_values.csv` | 1,050 rows: 75 porosity values for each selected window; coarse coordinates, channel counts, and standardized values. |
| `selected_window_metrics.csv` | Fourteen window summaries, quantiles, tail counts, fourth-moment contribution and shape/scale decomposition. |
| `selected_extreme_cells.csv` | Minimum, second minimum, maximum, and second maximum coordinates and values. |
| `geological_context_coarse_cells.csv` | Seventy-five coarse-cell records per window, with eight-cell source-coordinate bounds and facies counts. |
| `geological_context_fine_cells.csv` | Six hundred source-cell records per window: one-based source coordinates, original facies, and porosity. |
| `geological_context_windows.csv` | Facies totals, channel/tie/non-channel coarse-cell counts, and extrema for each window. |
| `geological_context_details.json` | Archived spatial and geological audit, including surrounding-cell context. |
| `*_verified_window_statistics.csv` | Full facies-valid search support, in original z/y/x order. `source_row` is the zero-based complete-window row before facies-valid filtering. |
| `reconstruction_audit.csv` | Archived differences between re-extracted coarse-grid statistics and the original calculation records. |
| `independently_extracted_samples.csv` | Coordinate-key extraction used in the original independent numerical check. |
| `independent_check_results.json` | Archived 50-digit recomputation and comparison with the original C++ fourth-cumulant outputs. |
| `provenance/source_provenance_original.json` | Original source-file hashes and historical workstation paths recorded during the analysis. |
| `provenance/original_protocol.md` | Original dated screening protocol, preserved verbatim. |
| `provenance/packaged_sources.json` | Hashes of the original copied files and the package-relative names. |
| `SHA256SUMS` | SHA-256 hashes of the package files. |

The keys `(dataset, role, window)` identify a selected window; the geological exports use `side` instead of `window`. `role=primary` denotes the first primary-tolerance pair, `role=strict` the first strict-tolerance pair, and `role=small_difference_control` the recorded low-difference control in z45_56.

## Statistical definitions and interpretation

`variance` is the population central second moment with denominator 75. `lambda3` is skewness; `lambda4` is excess kurtosis. `kappa4 = mu4 - 3*variance^2 = lambda4*variance^2`. `high_fraction` counts values at least 0.25 and divides by 75. `D = abs(kappa4_A-kappa4_B) / ((variance_A+variance_B)/2)^2`.

The selected pairs illustrate local tail contrasts under matched mean, variance, high-porosity fraction, and skewness. Pair selection is purposeful: each displayed strict pair maximizes `D` among strict candidates in that subvolume. Full matching and ordering rules are in `PROTOCOL.md`. Candidate pairs can share windows, and pair counts describe search support. Non-overlap means that the two windows have no common coarse-grid cells.

## Coordinates and original data

Processed coarse-grid coordinates are one-based. The three subvolumes have x=1..75, y=1..100, and z=15..26, 45..56, or 75..86. A window centred at `(x,y,z)` covers `x-2..x+2`, `y-2..y+2`, and `z-1..z+1`.

The original Stanford VI-E array is 150 x 200 x 200, with x varying fastest. Coarse porosity is the mean of each 2 x 2 x 2 source block; processed coarse y and z are reversed after aggregation. For a processed coarse cell `(x,y,z)`, its source one-based fine-coordinate starts are `(2*(x-1)+1, 2*(100-y)+1, 2*(100-z)+1)`, with each axis covering that start and the next index. These relationships are checked for all exported fine cells.

Original facies codes are 0=Floodplain, 1=Point bar, 2=Channel, and 3=Boundary. A coarse cell's `channel_count`/`nC` counts channel facies among its eight source cells. Counts greater than 4 identify channel centres, counts less than 4 non-channel centres, and count 4 is a tie. Screening retains facies-valid centres; all 75 porosity values within each retained window enter its statistics.

Original model repository: https://github.com/SCRFpublic/Stanford-VI-E

The source hashes identify the exact archived inputs. Historical absolute paths in the provenance record describe the original analysis location; all executable input locations use package-relative defaults or command-line arguments. The archived 510 MB `direct_analysis_values.csv` is represented by its source hash and the packaged verified statistics relevant to this analysis. Fresh verification results are written to the output directory specified on the command line.


## Figure S16

Editable SVG and 1200 ppi LZW TIFF versions are included in `figures/`. Regenerate the SVG with `python scripts/make_figure_s16.py --output-dir ../figure_s16_rebuilt`. The script reads package-relative input CSVs and uses only the Python standard library. `scripts/README_Figure_S16.md` describes optional TIFF export.
