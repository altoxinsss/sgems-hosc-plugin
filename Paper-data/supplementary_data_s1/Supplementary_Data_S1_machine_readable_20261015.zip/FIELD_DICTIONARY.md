# Manuscript notation and field dictionary

The companion manuscript is *An integrated SGeMS plugin for high-order statistics calculation*.

## Direct local-statistic comparisons

| Symbol or field | Meaning |
|---|---|
| kappa4 / k4 | Unstandardized fourth cumulant. Numeric machine fields retain their original spelling. |
| lambda3 | Standardized third cumulant, or skewness. |
| lambda4 | Standardized fourth cumulant, or excess kurtosis. |
| lambda5 / lambda6 | Standardized fifth/sixth cumulant using the same window variance and fixed normalized weights. |
| effect_E / E | Signed channel-minus-nonchannel group mean difference divided by sqrt((s_C^2+s_N^2)/2); each group variance uses n-1. |
| separation_S / S | abs(E), calculated within each subvolume before averaging. |
| A4 / A5 / A6 | S of k4 / lambda5 / lambda6 minus the largest same-scheme S among mean, variance, high_fraction, lambda3, lambda4, selected within each subvolume. |
| W / Delta S | Weighted-minus-uniform change in S for the same attribute and paired support. |
| G / Delta A | Weighted-minus-uniform change in A. |
| macro_equal_dataset | Equal-weight mean of the three within-subvolume estimates, not pooled-window analysis and not abs(mean(E)). |
| high_fraction / H | Under uniform weighting, within-window fraction of porosity values at least 0.25. |
| high_fraction / H_w | Under nonuniform weighting, sum of normalized weights on porosity values at least 0.25; uniform weighting gives H_w=H. |
| point_estimate | Statistic on the observed sample, used in the tables. |
| bootstrap_mean | Mean of bootstrap replicate statistics; not substituted for point_estimate. |
| ci95_low / ci95_high | 2.5th and 97.5th percentiles of the recorded coordinate-block replicate estimates. |
| channel_q1 / channel_q3 / nonchannel_q1 / nonchannel_q3 | Group quartiles, not confidence limits. |
| bootstrap_scope | primary, scale, large_block, or parameter_sensitivity; retain the specified scope when selecting a result. |
| bootstrap_seed | Integer pseudorandom seed; the digits are not an experiment date. |

Within each subvolume, E, S, the strongest simple baseline, A, and weighting contrasts are calculated before equal-subvolume averaging. The strongest baseline is reselected in each bootstrap replicate. Paired contrast intervals are read from their own records and are not obtained by subtracting two absolute interval endpoints. Section 4.5 and Section 4.6 uniform point estimates coincide, but their recorded bootstrap intervals differ; select the section-specific rows.

Primary comparison support: z15-26 has 67,332 centers (12,923 channel and 54,409 nonchannel); z45-56 has 66,485 (7,612 and 58,873); z75-86 has 63,463 (28,430 and 35,033). Three-scheme comparisons use their shared facies-valid centers. Each subvolume has 68,160 complete numerical 5x5x3 windows before the facies filter.

Primary Panel C filters are section=4.5 or 4.6, dataset_id=macro_equal_dataset, window=5x5x3, parameter_role=primary, bootstrap_scope=primary, metric_family=direct_effect and metric_name=separation_S. The six features are mean, variance, high_fraction, lambda3, lambda4 and kappa4. The primary bootstrap uses 2,000 replicates, seed 20261011 and 8x13x6 coordinate blocks. Tables S9 and S10 use their own section keys. Complete row selections appear in TABLE_TO_FILE_MAP.csv.

## Weighting and concentration

U, CG and SHP mean uniform, coordinate-Gaussian and soft high-porosity weighting. Primary parameter sets are uniform, coordinate_gaussian_sigma_1.00, and soft_high_porosity_width_0.02_strength_0.80. The associated parameters are sigma_s=1; porosity midpoint tau=0.25, width b=0.02 and strength eta_v=0.8. Scheme weights are normalized within each window and held fixed over all moment orders.

ESS=1/sum(p_i^2) and ESS/N summarize concentration of normalized contributions. They do not count spatially independent observations. S15's mean within-window H_w is obtained by weighting channel/nonchannel means by their counts inside each subvolume, followed by equal-subvolume averaging. The SHP subvolume values are 0.2845011847524402, 0.22418509351721766 and 0.25666697922607545; their mean is 0.25511775249857777. This is the companion Word figure's quantity, distinct from the archived upper-tail-allocation plot.

## Fixed-rank conditional shape analysis

Ranks use average ties divided by n+1 within each complete subvolume. For lambda5, controls are mean, log variance, high_fraction, lambda3 and lambda4, plus an intercept. Lambda6 additionally includes lambda5. Cumulant ranks and shape ranks are separately projected on those controls. conditional_rank_association is the correlation of their residuals; conditional_residual_slope regresses the shape residual on the cumulant residual. unexplained_rank_variance is 1-R^2 for the cumulant-rank regression. Its six-row summary supplies point estimates without confidence intervals.

For standardized within-window porosity u, lower_tail_probability=P(u<=-1.5); upper_tail_probability=P(u>=1.5); outer_tail_probability is their sum; tail_imbalance is upper minus lower. q05, q10, q90 and q95 are linear-interpolation empirical quantiles; outer_span_q05_q95=q95-q05. Conditional analyses retain the 68,160 numerical windows per subvolume and do not impose the facies grouping filter. Low/high groups use the 20th/80th percentiles of cumulant-rank residuals, with 13,632 windows per group per subvolume. Bootstrap re-fits projections while retaining the full-subvolume ranks.

Direct separation and fixed-rank shape summaries are descriptive statistical analyses, with no classifier, cross-validation or out-of-fold M4/M6 prediction metric in these files.

## Coordinates and template responses

Original dimensions are 150x200x200 in x/y/z; contiguous 2x2x2 reduction gives 75x100x100, stored as [100,100,75] in z/y/x order. Preprocessing records the y/z reversals. Processed-grid coordinates are one-based; x varies fastest; physical cell spacing is 50x50x2 m. The local-window centers in each retained layer span x=3..73 and y=3..98. Zero-based raster indices in S12/S13 become these source center indices after adding 3.

Template lag coordinates differ from moving-window geological coordinates. standardized_k4 in template records is the raw joint cumulant divided by the squared population-form variance of the relevant field support. It is not the moving-window lambda4. S4 counts 25 lag-grid positions including zero-lag positions, of which 16 have both lag indices nonzero; S6 records 64 unique 3-D lag combinations per property/subvolume, shared by the two evaluator routes.

## Timing units and source paths

wall_time_s and internal_time_s are seconds. Peak working-set fields retain the historical *_mb spelling; manuscript values derived from byte counts divided by 2^20 are reported in MiB. Table S1 summaries use phase=recorded,status=PASS; warm-up rows remain as records. Historical absolute paths in source manifests identify provenance; relative paths in FIGURE_TO_FILE_MAP.csv are relative to the sgems-hosc-plugin repository root. Raw Stanford VI-E inputs are described by Paper-data/raw_data/README.txt and the preprocessing manifest.


## Matched fourth order windows

The new directory supplies Table S11, main-text Table 4 and Fig. 8, and Supplementary Fig. S16. `mean`, `variance`, `lambda3`, `lambda4`, and `kappa4` are population-form local summaries of the same 75 values. `lambda4` is excess kurtosis and `kappa4 = lambda4 * variance**2`. `D = abs(kappa4_A-kappa4_B) / ((variance_A+variance_B)/2)**2`. High-porosity counts use porosity >= 0.25. Centers and coarse extrema are one-based processed-grid indices; original fine-grid coordinates are separately recorded. Each selected window maps to 600 fine cells. Labels 0/1/2/3 are Floodplain/Point bar/Channel/Boundary. All tied extrema are retained. `PROTOCOL.md` defines fixed primary/strict tolerances, non-overlap and ranking. Candidate pairs may reuse individual windows. See the directory README for field keys, portable scripts and coordinate mapping.
