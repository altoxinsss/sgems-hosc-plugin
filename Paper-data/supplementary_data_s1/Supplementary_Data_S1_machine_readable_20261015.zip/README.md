# Supplementary Data S1

Companion manuscript: **An integrated SGeMS plugin for high-order statistics calculation**.

This package provides the full-precision numerical records for Supplementary Tables S1-S11, including the complete baseline comparisons in S9 Panel C and S10 Panel C, together with coordinate and numerical audit records. The figures are identified by their companion Word versions and mapped to the existing data sources in `FIGURE_TO_FILE_MAP.csv`.

## Contents

- `TABLE_TO_FILE_MAP.csv` gives table, panel, feature and weighting selection rules.
- `FIELD_AND_SOURCE_MANIFEST.csv` records numerical artifacts, historical source paths, original source hashes, package hashes and selection rules.
- `FIELD_DICTIONARY.md` defines E, S, A, W=Delta S, G=Delta A, equal-subvolume averaging, H/H_w, confidence intervals and coordinate conventions.
- `Table_S9_full_estimates_intervals_bootstrap.csv` contains 1,048 recorded estimates/intervals with bootstrap counts, seeds, block shapes and scopes for both S9 and S10.
- `Table_S9_S10_Panel_C_selected_24_rows.csv` contains 24 full-precision rows selected without numerical conversion from that file: 6 rows for S9/C and 18 for S10/C. Original field strings and column order are retained.
- `FIGURE_TO_FILE_MAP.csv` covers current main-text Figs. 1-9 and Supplementary Figs. S1-S16. It records the accepted-view embedded-image hash and separates final Word display versions from older repository plots. Repository data paths are relative to the `sgems-hosc-plugin` root.
- `Table_S1_timing_records.csv` retains 160 recorded and 32 warm-up rows. S1 summaries use the five `phase=recorded,status=PASS` measurements per case/route.
- The S4 extracts retain 1,200 axial/diagonal records and 288 original-field reference records; the configuration audit records the 25/16 grid counts. The S6 table retains the 64 unique 3-D lag coordinates per property/subvolume without counting evaluator routes as independent coordinates.

## Provenance and scope

All 33 numerical artifacts from the preceding package are retained byte-for-byte, including its 24-row selection. Historical source paths, hashes, original creation time and packaging revisions remain in the manifests. The added `matched_fourth_order_windows/` directory contains seven selected pairs (14 windows), complete values and facies records, the three verified search-support tables, Table S11 exports, Figure S16 in editable SVG and TIFF, and portable verification and screening scripts. The case analysis reuses existing model outputs; no new simulations or bootstrap intervals are introduced.

This is the machine-readable companion to the manuscript and supplementary Word. Some older figure plotting files remain mapped to their recorded repository paths. Source attribution for the Stanford VI-E model is given in the matched-window README and the repository raw-data README. Original workstation paths are historical provenance; executable scripts use relative inputs or command-line arguments.

For S9/C select section=4.5 and uniform; for S10/C select section=4.6 and each of the three primary weighting schemes. Shared keys are dataset_id=macro_equal_dataset, window=5x5x3, parameter_role=primary, bootstrap_scope=primary, metric_family=direct_effect and metric_name=separation_S. Use point_estimate and its own ci95_low/ci95_high. Do not copy the section-4.5 uniform intervals into section 4.6 or replace observed estimates with bootstrap_mean.

S10 Panel B retains paired changes from the W/G records; Panel C contains absolute S values. Group quartiles in S7 are not confidence intervals. The S15 Word plot shows mean within-window high-porosity weight share, with SHP subvolume means 0.285, 0.224 and 0.257; it is distinct from the archived repository upper-tail-allocation plot.

## Matched-window reproducibility

See `matched_fourth_order_windows/README.md` for selected-window verification, full candidate reconstruction, Table S11 export, and Figure S16 generation. The selected-window verifier and SVG generator require only Python 3.10 or later; candidate reconstruction additionally requires NumPy and SciPy. All output paths are configurable.

## Integrity verification

`SHA256SUMS.txt` covers every other package member. Recompute each file's SHA-256 and compare with the listed digest. `PACKAGE_BUILD_MANIFEST.json` records the original numerical artifact hashes and this packaging revision. No artifact should be identified solely by an old figure filename when the Word and archived plotting versions differ.
